var Clases;
(function (Clases) {
    var Animal = /** @class */ (function () {
        function Animal(tipo, patas, edad) {
            this.tipo = tipo;
            this.patas = patas;
            if (edad)
                this.edad = edad;
        }
        Animal.prototype.Saludar = function () {
            console.log();
        };
        return Animal;
    }());
    Clases.Animal = Animal;
})(Clases || (Clases = {}));
