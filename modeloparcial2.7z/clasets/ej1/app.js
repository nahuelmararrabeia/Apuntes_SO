var unamascota = new Clases.Mascota(Clases.Tipo["4"], 0, 2, 'nemo');
console.log(unamascota);
var unAnimal = new Clases.Animal(Clases.Tipo["0"], 2, 25);
console.log(unAnimal);
