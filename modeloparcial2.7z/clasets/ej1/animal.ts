namespace Clases
{
    export class Animal{
        tipo:Tipo;
        patas:number;
        edad:number;
        static comio:boolean;
    
        constructor(tipo:Tipo,patas:number,edad?:number){
            this.tipo = tipo;
            this.patas = patas;
            if(edad) this.edad = edad;
        }
    
        Saludar():void{
            console.log();
        }
    }
}