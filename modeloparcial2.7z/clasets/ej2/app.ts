$(document).ready(function(){
    $("#mih1").text("chau");
})