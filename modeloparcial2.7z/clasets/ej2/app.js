"use strict";
$(document).ready(function () {
    $("#mih1").text("chau");
});
