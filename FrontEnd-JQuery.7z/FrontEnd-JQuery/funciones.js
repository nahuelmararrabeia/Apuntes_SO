

var servidor="http://localhost:8080/BackEnd-PHP/api/";

function porGet()
{
	

	console.log("porGet");
	$.ajax({
		 type: "get",
		url: servidor,
		data: {
	        datosLogin: {
		        usuario: "algunCorreo",
		        clave: "algunaClave" 
    		}
    	}
   		
	})
	.then(function(retorno){
		console.info("bien",retorno);
		
		
		
	
	},function(error){
		alert(error.responseText);
		console.info("error",error);
	});
	
	
}
function porPost()
{
	

	console.log("porGet");
	$.ajax({
		 type: "post",
		url: servidor,
		data: {
	        datosLogin: {
		        usuario: "algunCorreo",
		        clave: "algunaClave" 
    		}
    	}
   		
	})
	.then(function(retorno){
		console.info("bien",retorno);
		
		
		
	
	},function(error){
		alert(error.responseText);
		console.info("error",error);
	});
	
	
}