<?php
include_once "clases/AccesoDatos.php";
include_once "clases/cd.php";

isset($_POST["opcion"]);
//....
$opcion = $_POST["opcion"];

switch ($opcion) {
    case 'mostrar':
        echo cd::TraerTodoLosCdsJSON();
        break;

    case 'alta':
        $cd = new cd($_POST["titulo"],$_POST["cantante"],$_POST["año"]);
        // $cd = new cd();
        // $cd->titulo = $_POST["titulo"];
        // $cd->cantante = $_POST["cantante"]; 
        // $cd->año = $_POST["año"];

         $cd->InsertarElCdParametros();
    break;
    case "baja":
        $cd = new cd();
        $cd->id = $_POST["id"];
        $cd->BorrarCd();
    break;
    
    default:
        
        break;
}

?>