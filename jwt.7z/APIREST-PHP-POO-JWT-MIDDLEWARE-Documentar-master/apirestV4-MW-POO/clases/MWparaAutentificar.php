<?php


class MWparaAutentificar
{
 /**
   * @api {any} /MWparaAutenticar/  Verificar Usuario
   * @apiVersion 0.1.0
   * @apiName VerificarUsuario
   * @apiGroup MIDDLEWARE
   * @apiDescription  Por medio de este MiddleWare verifico las credeciales antes de ingresar al correspondiente metodo 
   *
   * @apiParam {ServerRequestInterface} request  El objeto REQUEST.
 * @apiParam {ResponseInterface} response El objeto RESPONSE.
 * @apiParam {Callable} next  The next middleware callable.
   *
   * @apiExample Como usarlo:
   *    ->add(\MWparaAutenticar::class . ':VerificarUsuario')
   */
	public function VerificarUsuario($request, $response, $next) {
         
		  if($request->isGet())
		  {		     
		     $response = $next($request, $response);
		  }
		  else
		  {	
				$ArrayDeParametros = $request->getParsedBody();
		    $nombre=$ArrayDeParametros['usuario'];
		    $clave=$ArrayDeParametros['clave'];	    
				$datos = array('usuario' => $nombre,'clave' => $clave);
				$token= AutentificadorJWT::CrearToken($datos);		    
		  }		  
		  return $response;   
	}
}