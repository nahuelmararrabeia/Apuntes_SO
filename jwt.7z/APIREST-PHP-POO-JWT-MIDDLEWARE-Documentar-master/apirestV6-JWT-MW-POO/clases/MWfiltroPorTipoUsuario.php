<?php
class MWfiltroPorTipoUsuario{
    public function Filtrar($request,$response,$next)
    {
        
    }
}