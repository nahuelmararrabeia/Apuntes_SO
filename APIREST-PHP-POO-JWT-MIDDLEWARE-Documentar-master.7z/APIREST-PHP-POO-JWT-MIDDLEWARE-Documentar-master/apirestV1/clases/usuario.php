<<?php 
/**
* 
*/
class Usuario 
{
	public $id;
	public $nombre;
	public $clave;

	public function NuevoUsuario($request,$response)
	{
		$ArrayDeParametros = $request->getParsedBody();
		$user = new Usuario();
		$user->nombre = $ArrayDeParametros['nombre'];
		$user->clave = $ArrayDeParametros['clave'];
		$user->CargarUsuario();
	}

	public function CargarUsuario()
	 {
	 		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("
				insert into usuarios (nombre,clave) 
				values (:nombre,:clave)");	
				$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_INT);		
				$consulta->bindValue(':clave',$this->clave, PDO::PARAM_INT);		
				$consulta->execute();
				return $consulta->rowCount();
	 }

	 public function EliminarUsuario($request,$response)
	 {
	 	$ArrayDeParametros = $request->getParsedBody();
	 	$user = new Usuario();
	 	$user->nombre = $ArrayDeParametros['nombre'];
		$user->clave = $ArrayDeParametros['clave'];
		$user->BorrarUsuario();
	 }

	 public function BorrarUsuario()
	 {
	 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("
				delete from usuarios 
				where nombre = :nombre and clave = :clave");	
				$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_INT);		
				$consulta->bindValue(':clave',$this->clave, PDO::PARAM_INT);		
				$consulta->execute();
				return $consulta->rowCount();
	 }
}
 ?>