<?php
include "./nexo.php";


date_default_timezone_set("America/Argentina/Buenos_Aires");

//if(count($_GET)> 0)
//{
//	Nexo::buscarUsuario($_GET["apellido"]);
//}else if (count($_POST)> 0)
//{
	Nexo::crearUsuario($_POST["nombre"], $_POST["apellido"], $_POST["email"]);

$extension = pathinfo($_FILES["imagen"]["name"])["extension"];
$destino = "./img/".$_POST["email"].".".$extension;
if(file_exists($destino))
{	
	$nombreArchivo = pathinfo($destino)["filename"];
	$fecha = date("Ymd_His");
	$archivoBackup = "./img/backup/".$nombreArchivo."-".$fecha.".".$extension;		
	rename($destino, $archivoBackup);
}
move_uploaded_file($_FILES["imagen"]["tmp_name"], $destino);
//}

//if($_GET)
//Nexo::buscarUsuario($_GET["apellido"]);
?>