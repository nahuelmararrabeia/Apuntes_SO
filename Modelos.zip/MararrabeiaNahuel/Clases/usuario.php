<?php
	class Usuario
	{
		public $nombre;
		public $apellido;
		public $email;


		function __construct($name, $apellido, $mail)
		{
			$this->nombre = $name;
			$this->apellido = $apellido;
			$this->email = $mail;
		}

		function ToString(){
			$salida = "$this->email - $this->apellido - $this->nombre";
			return $salida;
		}
		
	}

?>

