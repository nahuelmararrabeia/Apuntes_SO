<?php
include "./Clases/usuario.php";

/**
* 
*/
class Nexo
{
		static function crearUsuario($nombre,$apellido,$email){	
	$flag = false;
		$usuarios = array();
		$archivoDatos = fopen("./datos/usuarios.txt", "r");	   		
       		while(!feof($archivoDatos)) {    	
       		$linea = fgets($archivoDatos);
       		$obj = json_decode($linea,true);
       		$user = new Usuario($obj["nombre"],$obj["apellido"],$obj["mail"]);
			array_push($usuarios, $user);
	}
	fclose($archivoDatos);
	$usuario = new	Usuario($nombre, $apellido, $email);
	array_push($usuarios,$usuario);
	$archivo = fopen("./datos/usuarios.txt", "w+");
	foreach ($usuarios as $i) {
		if($flag)
		{ fwrite($archivo, "\n"); }
		fwrite($archivo,json_encode($i));
		$flag = true;
		}
		fclose($archivo);
}
static function buscarUsuario($apellido){
	$flag = false;
	$usuarios = array();
		$archivoDatos = fopen("./datos/usuarios.txt", "r");	
   		while(!feof($archivoDatos)) {    	
       		$linea = fgets($archivoDatos);
       		$obj = explode('-', $linea);
       		$user = new Usuario($obj[2],$obj[1],$obj[0]);
       		if($apellido == $user->apellido){
       			array_push($usuarios, $user);
       			$flag = true;
       		}
			
	}
	fclose($archivoDatos);
	if($flag = true){
		foreach ($usuarios as $i) {
		echo $i->ToString();
	}
	}else{
		echo "no existe usario para $apellido";
	}
	
}

static function listarUsuarios()
{
	$tabla = "<table>";
	$usuarios = array();
		$archivoDatos = fopen("./datos/usuarios.txt", "r");	
   		while(!feof($archivoDatos)) {
       		$linea = fgets($archivoDatos);
       		$obj = explode('-', $linea);       		
       		$user = new Usuario($obj[2],$obj[1],$obj[0]);
			$tabla = $tabla."<tr><td>".$user->apellido."</td><td>".$user->nombre."</td><td>".$user->email."</td></tr>";
	}
	fclose($archivoDatos);
	$tabla = $tabla."</table>";

}		
	
}


?>